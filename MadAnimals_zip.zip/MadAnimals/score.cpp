#include "score.hpp"
using namespace std;
#include <iostream>


//different srcRects for different digits
void Score::draw(int digit){
    
    if (digit==0)
    {
        srcRect={368,176,26,33};
    }
    if (digit==1)
    {
            srcRect={134,110,19,32};
    }
    if (digit==2)
    {
        srcRect={190,110,24,32};
    }
    if (digit==3)
    {
        srcRect={250,110,22,33};
    }
    if (digit==4)
    {
        srcRect={309,110,26,33};
    }
    if (digit==5)
    {
        srcRect={369,110,22,33};
    }
    if (digit==6)
    {
        srcRect={166,176,23,33};
    }
    if (digit==7)
    {
        srcRect={225,176,24,33};
    }
    if (digit==8)
    {
        srcRect={273,176,24,33};
    }
    if (digit==9)
    {
        srcRect={321,176,23,33};
    }

    SDL_RenderCopy(Drawing::gRenderer, Drawing::assets3, &srcRect, &moverRect);
    
}


Score::Score(int x, int y)
{
    moverRect={x, y, 50, 50};
}