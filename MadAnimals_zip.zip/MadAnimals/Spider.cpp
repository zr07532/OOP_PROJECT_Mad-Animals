#include "Spider.hpp"

void Spider::fly(){
    //these if conditions check the movement of the object to decide which image to show on screen
    if (state == 0)
    {
        srcRect = {1116, 324, 229, 216};    //state changes every time to show animation
        state += 1; 
    }
    else if (state == 1)
    {
        srcRect = {1346, 324, 242, 216};
        state += 1;
    }
    else if(state == 2)
    {
        srcRect = {873, 324, 242, 213};
        state -= 2;
    }
    else
    {
        state = 0;
    }
     moverRect.y += 10; //a spider moves 10 units forward on y axis

}

Spider::Spider(){
    // src coorinates from assets.png file, they have been found using spritecow.com
    srcRect = {1116, 324, 229, 216};

    // it will display spider on x = 30, y = 40 location, the size of pigeon is 50 width, 50 height
    moverRect = {30, 40, 50, 50};
}
Spider::Spider(int x, int y) 
{
    // src coorinates from assets.png file, they have been found using spritecow.com
    srcRect = {1116, 324, 229, 216};

    // it will display pigeon on x, y location, the size of pigeon is 50 width, 50 height
    moverRect = {x, y, 50, 50};
}

