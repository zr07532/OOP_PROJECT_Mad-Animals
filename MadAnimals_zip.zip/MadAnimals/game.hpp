#pragma once

#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <iostream>
#include <string>
#include <stdlib.h>
#include <time.h>
#include <SDL_mixer.h>
#include "score.hpp"

class Game{
    //Screen dimension constants
    const int SCREEN_WIDTH = 1500;
    const int SCREEN_HEIGHT = 750;

    //The window we'll be rendering to
    SDL_Window* gWindow = NULL;

    //Current displayed texture
    SDL_Texture* gTexture = NULL;

    SDL_Texture * assets;
    SDL_Texture * assets1;
    SDL_Texture * assets2;
    SDL_Texture * assets3;
    Mix_Music* music=NULL;
    bool restart=false;
    
   
    int state=0;
    int shooter_movement=0;
    

public:

    Score* s1;
    Score * s2;
    Score * s3;
    bool paused =false;
    int fire = 0;
    bool init();
    bool loadMedia();
    void close();
    SDL_Texture* loadTexture( std::string path );
    void run();
    int counter=0;
    bool pause = false;
    bool state_4=false;
    bool p_again = false;
};

