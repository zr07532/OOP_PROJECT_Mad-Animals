#include "game.hpp"
#include "MadAnimals.hpp"
#include "drawing.hpp"
#include <iostream>
using namespace std;
SDL_Renderer* Drawing::gRenderer = NULL;
SDL_Texture* Drawing::assets = NULL;
SDL_Texture* Drawing::assets1 = NULL;
SDL_Texture* Drawing::assets2 = NULL;
SDL_Texture* Drawing::assets3 = NULL;

bool Game::init()
{
	//Initialization flag
	bool success = true;


	//Initialize SDL
	if( SDL_Init( SDL_INIT_VIDEO ) < 0 )
	{
		printf( "SDL could not initialize! SDL Error: %s\n", SDL_GetError() );
		success = false;
	}
	else
	{
		//Set texture filtering to linear
		if( !SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY, "1" ) )
		{
			printf( "Warning: Linear texture filtering not enabled!" );
		}

		if( Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0 )
    	{
			printf( "Unable to open audio: %s\n", Mix_GetError());
			success=false;
    	}

		//Create window
		gWindow = SDL_CreateWindow( "Mad Animals", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN );
		if( gWindow == NULL )
		{
			printf( "Window could not be created! SDL Error: %s\n", SDL_GetError() );
			success = false;
		}
		else
		{
			//Create renderer for window
			Drawing::gRenderer = SDL_CreateRenderer( gWindow, -1, SDL_RENDERER_ACCELERATED );
			if( Drawing::gRenderer == NULL )
			{
				printf( "Renderer could not be created! SDL Error: %s\n", SDL_GetError() );
				success = false;
			}
			else
			{
				//Initialize renderer color
				SDL_SetRenderDrawColor( Drawing::gRenderer, 0xFF, 0xFF, 0xFF, 0xFF );

				//Initialize PNG loading
				int imgFlags = IMG_INIT_PNG;
				if( !( IMG_Init( imgFlags ) & imgFlags ) )
				{
					printf( "SDL_image could not initialize! SDL_image Error: %s\n", IMG_GetError() );
					success = false;
				}

			}
		}
	}

	return success;
}

bool Game::loadMedia()
{
	//Loading success flag
	bool success = true;
	music=Mix_LoadMUS("mainscreen.mp3");
	Drawing::assets = loadTexture("assets.png");
	Drawing::assets1=loadTexture("explode.png");
	Drawing::assets2=loadTexture("bullet.png");
	Drawing::assets3=loadTexture("numbers.png");

    gTexture = loadTexture("main_screen2.png");

	if(Drawing::assets==NULL || gTexture==NULL || Drawing::assets1==NULL || Drawing::assets2==NULL)
    {
        printf("Unable to run due to error: %s\n",SDL_GetError());
        success = false;
    }
	return success;
	if( music == NULL )
    {
        printf( "Failed to load beat music! SDL_mixer Error: %s\n", Mix_GetError() );
        success = false;
    }
}

void Game::close()
{
	//Free loaded images
	SDL_DestroyTexture(Drawing::assets);
	Drawing::assets=NULL;
	Drawing::assets1=NULL;
	Drawing::assets2=NULL;
	Drawing::assets3=NULL;
	SDL_DestroyTexture(gTexture);
	
	//Destroy window
	SDL_DestroyRenderer( Drawing::gRenderer );
	SDL_DestroyWindow( gWindow );
	gWindow = NULL;
	Drawing::gRenderer = NULL;
	Mix_FreeMusic(music);
    music = NULL;
	
	//Quit SDL subsystems
	Mix_Quit();
	IMG_Quit();
	SDL_Quit();
}

SDL_Texture* Game::loadTexture( std::string path )
{
	//The final texture
	SDL_Texture* newTexture = NULL;

	//Load image at specified path
	SDL_Surface* loadedSurface = IMG_Load( path.c_str() );
	if( loadedSurface == NULL )
	{
		printf( "Unable to load image %s! SDL_image Error: %s\n", path.c_str(), IMG_GetError() );
	}
	else
	{
		//Create texture from surface pixels
        newTexture = SDL_CreateTextureFromSurface( Drawing::gRenderer, loadedSurface );
		if( newTexture == NULL )
		{
			printf( "Unable to create texture from %s! SDL Error: %s\n", path.c_str(), SDL_GetError() );
		}

		//Get rid of old loaded surface
		SDL_FreeSurface( loadedSurface );
	}

	return newTexture;
}
void Game::run( )
{
	//main object created
	MadAnimals madanimals;
	bool quit = false;
	SDL_Event e;


	while( !quit )
	{
		//Handle events on queue
		while( SDL_PollEvent( &e ) != 0 )
		{
			//User requests quit
			if( e.type == SDL_QUIT )
			{
				quit = true;
			}

			if(e.type == SDL_MOUSEBUTTONDOWN)
			{

				int xMouse, yMouse;
				SDL_GetMouseState(&xMouse,&yMouse);
				//when player clicks on play game
				if (xMouse>334 && yMouse>439 && xMouse<685 && yMouse<508 && state==0)
				{
					music=Mix_LoadMUS("click.wav"); //click sound plays
					Mix_PlayMusic(music,0);
					gTexture = loadTexture("Game.png"); //new screen texture opened
					state=2; //state is changed to indicate that we are now on Game play screen
					
					if (p_again == true){  //check if play again is true
						
						madanimals.createObject(); 
						madanimals.p_again();
						p_again = false;

					}
				}

				//if instructions button is pressed
				else if (xMouse>891 && yMouse>443 && xMouse<1228 && yMouse<508 && state==0)
				{
					//madanimals.deleteObject();
					music=Mix_LoadMUS("click.wav");
					Mix_PlayMusic(music,0);
					gTexture = loadTexture("instructions.png");	
					state=1; //each time a button is pressed and screen changes, state is changed
					
				}

				//when on instructions page, player presses back button
				else if (xMouse>88 && yMouse>582 && xMouse<210 && yMouse<659 && state==1)
				{
					music=Mix_LoadMUS("click.wav");
					Mix_PlayMusic(music,0);
					gTexture = loadTexture("main_screen2.png");					
					state=0;
					
				}

				//when on instructions page, player presses play button
				else if(xMouse>1290 && yMouse>576 && xMouse<1408 && yMouse<656 && state==1)
				{
				
					music=Mix_LoadMUS("click.wav");
					Mix_PlayMusic(music,0);
					gTexture = loadTexture("Game.png");
					
					state = 2;
					if (p_again == true){
						
						madanimals.createObject();
						madanimals.p_again();
						p_again = false;

					}

				}	

				//when paused screen, and player pressed Quit Game		
				else if (xMouse>469 && yMouse>488 && xMouse<1027 && yMouse<621 && state==3)
				{
					music=Mix_LoadMUS("click.wav");
					Mix_PlayMusic(music,0);
					gTexture = loadTexture("main_screen2.png");
					madanimals.deleteObject();
					p_again = true;
					state=0;
				}	
				
				//when game over screen and player presses play again
				else if (xMouse > 467 && yMouse > 474 && xMouse < 1031 && yMouse < 611 && state==4)
				{
					music=Mix_LoadMUS("click.wav");
					Mix_PlayMusic(music,0);
					gTexture = loadTexture("main_screen2.png");
					madanimals.deleteObject();
					p_again = true;
					state=0;
				}
			}

			// pause / quit screen 
			if	(e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_ESCAPE && pause== false){
				gTexture = loadTexture("paused_scr.png");
				state = 3;
				pause = true;
				music=Mix_LoadMUS("mainscreen.mp3");
				Mix_PlayMusic(music,0);
			}

			else if	(e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_ESCAPE && pause==true)
			{
				gTexture = loadTexture("Game.png");
				state = 2;
				pause = false;
				music=Mix_LoadMUS("playing.mp3");
				Mix_PlayMusic(music,0);
			}


			//when arrow keys are pressed during game playing screen
			if	(e.type == SDL_KEYDOWN && state==2)
			{	
				if (e.key.keysym.sym == SDLK_LEFT)
				{
					shooter_movement=1;
					madanimals.sh->movement(shooter_movement); //movement is stored and passed to the shooter function
				}
				if 	(e.key.keysym.sym == SDLK_RIGHT)
				{	
					shooter_movement=2;
					madanimals.sh->movement(shooter_movement);
				}

				if 	(e.key.keysym.sym == SDLK_SPACE || e.key.keysym.sym == SDLK_UP)
				{	
					cout<<"Here"<<endl;
					madanimals.fire(); //collision function is implemented
					
				}
			}

		}

		SDL_RenderClear(Drawing::gRenderer); //removes everything from renderer
		SDL_RenderCopy(Drawing::gRenderer, gTexture, NULL, NULL);//Draws background to renderer
		
		
		//state logic
		if (state==1 || state==0) // main screen :: Instructions Screen s
		{
			if (Mix_PlayingMusic()==0)
			{
				music=Mix_LoadMUS("mainscreen.mp3");
				Mix_PlayMusic(music,0);
			}
		}

		if(state==2 && restart==false) // game screen 
		{
			if (Mix_PlayingMusic()==0)
			{
				music=Mix_LoadMUS("playing.mp3");
				Mix_PlayMusic(music,0);
			}
			
			counter = rand()%100;
			madanimals.drawObjects();

			//animals are created with certain probability
			if (counter>95)
			{
				madanimals.createObject();
			}			
		}

		if (state==2 && restart==true)
		{
			if (Mix_PlayingMusic()==0)
			{
				music=Mix_LoadMUS("playing.mp3");
				Mix_PlayMusic(music,0);
			}

			madanimals.deleteObject();
			madanimals.set_health();
			madanimals.set_score();
			
			counter = rand()%100;
			madanimals.drawObjects();
			if (counter>95)
			{
				madanimals.createObject();
			}
		}

		if (state==2 && madanimals.game_end()==true)
		{
			state=4;		
		}

		if(state==3) // state 3: paused screen 
		{
			if (Mix_PlayingMusic()==0)
			{
				music=Mix_LoadMUS("mainscreen.mp3");
				Mix_PlayMusic(music,0);
			}
		}

		if(state==4) // state 4: gameover
		{
			gTexture = loadTexture("gameover_screen.png");
			if (Mix_PlayingMusic()==0)
			{
				music=Mix_LoadMUS("mainscreen.mp3");
				Mix_PlayMusic(music,0);
			}
			state_4=true;
			madanimals.drawScore();
			madanimals.game_end()==false;
			madanimals.deleteObject(); //this function deleted everything
			
		}
		

		//****************************************************************
    	SDL_RenderPresent(Drawing::gRenderer); //displays the updated renderer

	    SDL_Delay(100);	//causes sdl engine to delay for specified miliseconds
	}
			
}
