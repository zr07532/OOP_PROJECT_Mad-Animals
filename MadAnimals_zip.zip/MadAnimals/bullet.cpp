#include "bullet.hpp"
using namespace std;
#include <iostream>

//implementing bullet upward motion
void Bullet::shot()
{
    cout<<"shooting"<<endl;
    moverRect.y-=30;
}



//function to draw bullet
void Bullet::draw()
{
    
    SDL_RenderCopy(Drawing::gRenderer, Drawing::assets2, &srcRect, &moverRect);

    shot();
}

Bullet::Bullet()
{
    srcRect = {267,139,39,165};
    moverRect = {50,50, 20, 70};
}

int Bullet::get_x()
{
    return moverRect.x;
}

int Bullet::get_y()
{
    return moverRect.y;
}

Bullet::Bullet(int x, int y)
{
    srcRect = {267,139,39,165};
    moverRect = {x+20, y-70, 30, 80};
}

SDL_Rect* Bullet::getMover()
{
    return &moverRect;
}