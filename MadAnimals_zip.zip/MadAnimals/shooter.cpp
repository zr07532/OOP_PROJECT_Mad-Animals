#include "shooter.hpp"
using namespace std;
#include <iostream>

// Shooter implementation 

void Shooter::draw(){
    SDL_RenderCopy(Drawing::gRenderer, Drawing::assets, &srcRect, &moverRect);    
}

// movement function connected with keyboard keys to make the shooter move left/right
void Shooter::movement(int move){

    if (move==1)
    {
        if (moverRect.x < 0)
        {
            moverRect.x = 1450;
        }
        cout<<"left"<<endl;
        moverRect.x=moverRect.x-30;
    }
    if (move==2)
    {
        if (moverRect.x > 1450)
            moverRect.x= 0;
            moverRect.x = moverRect.x+30;
    }    
}

bool Shooter::operator<(int i)
{
    if (health < i)
    {
        return true;
    }
    else
    {
        return false;
    }
}

bool Shooter:: operator>(int i)
{
    if (health > i)
    {
        return true;
    }
    else
    {
        return false;
    }
}


bool Shooter:: operator==(int i)
{
    if (health==i)
    {
        return true;
    }
    else
    {
        return false;
    }
}


// when shooter health == 0, shooter is destroyed
bool Shooter::destroyed()
{
    if (health==0)
    {
        return 1;
    }
    return 0;
}

int Shooter::get_health()
{
    return health;
}

void Shooter::set_health(int h)
{
    health=h;
}

int Shooter::get_x()
{
    return moverRect.x;
}

int Shooter::get_y()
{
    return moverRect.y;
}

SDL_Rect* Shooter::get_mover()
{
    return &moverRect;
}

//constructors for shooter implementation
Shooter::Shooter()
{
    // src coorinates from assets.png file, they have been found using spritecow.com
    srcRect={767,577,140,192};
    // it will display pigeon on x = 30, y = 40 location, the size of pigeon is 50 width, 50 height
    moverRect={400,750,70,70};
}

Shooter::Shooter(int x, int y)
{    
    // src coorinates from assets.png file, they have been found using spritecow.com
    srcRect={767,577,140,192};
    // it will display pigeon on x , y location, the size of pigeon is 50 width, 50 height
    moverRect={x,y,70,70};
}

void Shooter::set_cord(){
    moverRect.x = 730;
    moverRect.y = 650;
    
}
