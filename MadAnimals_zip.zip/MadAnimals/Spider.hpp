#pragma once
#include<SDL.h>
#include "drawing.hpp"
#include "Animal.hpp"
#include <iostream>

using namespace std;

// class for Spider implementation inherited from class Animal

class Spider: public Animal
{
    int state = 0; 

public:
    //These functions have been described in Bat.hpp
    void fly();
    Spider(); 

    Spider(int x, int y);
    ~Spider()
    {
        cout<<"Spiders deleted"<<endl;
    }
};
