#pragma once
#include "drawing.hpp"
#include<SDL.h>
#include<iostream>

using namespace std;
// Animal class is well implemented, no need to change it

class Explosion{
    protected:
    SDL_Rect srcRect, moverRect;


public:
    Explosion(){};   
    SDL_Rect* getMover();
    void draw();
    void fly();
    
    int get_y();
    bool complete=false;
    bool exploding=false;
    int state=0;
    Explosion(int x, int y);
    bool has_exploded();

    ~Explosion()
    {
        cout<<"Explosions deleted"<<endl;
    }

};
