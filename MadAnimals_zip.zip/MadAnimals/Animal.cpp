#include "Animal.hpp"
#include <iostream>

using namespace std;

// Unit class is well implemented, no need to change it

void Animal::draw(){
    
    SDL_RenderCopy(Drawing::gRenderer, Drawing::assets, &srcRect, &moverRect);
    //cout<<"Drawn"<<endl;
}

SDL_Rect* Animal::getMover()
{
    return &moverRect;
}

int Animal::get_y()
{
    return moverRect.y;
}

int Animal::get_x()
{
    return moverRect.x;
}


