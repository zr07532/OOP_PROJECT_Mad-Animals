#include <iostream>
#include "MadAnimals.hpp"


using namespace std;
//Function to generate random integer between 0 & 3 to randomly decide which object to draw and 
// return pointer of Animal type

//Design pattern 1 implementation:
class AnimalFactory
{
    public:   
    AnimalFactory()
    {};
    Animal* getObject()
    {
        int randomNumberx, randomNumbery;
        
            int prob = (rand() % 100) + 1 ;
            randomNumberx = 25 + (rand() % 1400);
            
            int y = 0;
            //on probability basis, objects are created
            if (prob < 33)
            {
                Animal * u = new Spider(randomNumberx,y);
                return u;
            }
            else if (prob >= 33 && prob <= 66)
            {
                Animal* u = new  Ladybug(randomNumberx, y);
                return u;
            }
            
            else if (prob >= 67 && prob <= 101) 
            {
                Animal * u = new Bat(randomNumberx,y);
                return u;
            }  
    }
};

//this function is responsible for drawing objects on the screen. It also has the functionality for collision,
// life, and score implementation
void MadAnimals::drawObjects()
{
    for(Animal* u: Animals) //looping through animals list
    {   
        for(Bullet*& b: list_bullets) //looping through bullets list
        { 
            if(SDL_HasIntersection (u->getMover(),b->getMover())) //collision of bullet and animal
            {
                                              
                explosive = new Explosion(b->get_x(),b->get_y()); //explosion object is created
                explosive->exploding=true;  
                cout<<"drawn explosion"<<endl;

                // bomb is dropped when animal dies, getting x and y co-ordinates of bullet where it hits animal
                int bomb_x= b->get_x();
                int bomb_y= b->get_y();

                // BOMB is dropped on probability bases 
                int r = rand() % 99;
                if (r < 45)                 
                bomb_drop(bomb_x , bomb_y);

                score+=5;
                delete u;
                Animals.remove(u);                
                delete b;
                list_bullets.remove(b);
                
            }
        }
    }
//the below code is for the implementation of collision of animal and shooter
    for (Animal * & u: Animals)
    {
        if (SDL_HasIntersection (u->getMover(),sh->get_mover()))
        {
            explosive = new Explosion(u->get_x(),u->get_y());
            explosive->exploding=true; //this sets the trigger for explosion animation

            music=Mix_LoadMUS("hit.wav"); //a hit sound is played whenever collision occurs
			Mix_PlayMusic(music,0);
            
            int health=sh->get_health()-1; //health is reduced whenever shooter is hit
            score-=5; //score reduces when shooter is hit
            sh->set_health(health); 
            delete u;
            Animals.remove(u);                
            
        }

    }
//the below code is responsible for bomb and shooter collision
    for (Bomb * & bom : list_bomb)
    {
        if (SDL_HasIntersection (bom->getMover(),sh->get_mover()))
        {
            explosive = new Explosion(bom->get_x(),bom->get_y());
            explosive->exploding=true; 

            music=Mix_LoadMUS("hit.wav"); // a hit sound is played whenever such collision occurs
			Mix_PlayMusic(music,0);
            int health=sh->get_health()-1;
            score-=5;
            sh->set_health(health);
            delete bom;
            list_bomb.remove(bom);     //bombs, bullets, objects are deleted simulataneously
            
        }
    }

    for (Animal  * & u: Animals)
    {
        if (u->get_y()>=700) //if animal reaches the end of the screen then it is deleted and score is 
        {              
                  // reduced by 10
            delete u;
            Animals.remove(u);                
            
            score-=10;
        }
    }

    
    for(Animal* u: Animals)  //all animal objects are drawn
    {  
        u->draw();            
        u->fly();
    }
    
    if (*sh > 0)  //OPERATOR OVERLOADING: if shooter has life then it is drawn
    {
        cout<<sh->get_health()<<endl;
        sh->draw();

    }

    if (*sh==0 || score==0)  // OPERATOR OVERLOADING:if shooter health is zero or score is 0, game has to end
    {
        cout<<"true"<<endl;
        flag=true;
    }
    
    // int a =*sh;
    

    if (score == bonus){     //for every 50+ score, one life bonus is given
        bonus += 50;
        bonus_health();
        music=Mix_LoadMUS("bonus.wav"); //bonus sound played in the background
        Mix_PlayMusic(music,0);
    }

    drawScore();

    //life objects are drawn according to shooter's health score
    l->draw(sh->get_health());
    
    int bullet_x=sh->get_x();
    int bulllet_y=sh->get_y();
    
    for(Bullet*& b: list_bullets)
    {   
        b->draw();
        if (b->get_y()<6) //if bullet reaches the top of the screen, it is deleted
        {
            delete b;
            list_bullets.remove(b);
            
        }        
    }
    if (explosive->exploding==true && explosive->complete==false) //this will enable complete explosion animation
    {
        explosive->draw();            
        explosive->fly();
    }
    
    for(Bomb*& bom: list_bomb)
    {   
        bom->draw();
        if (bom->get_y() > 730)  //if bomb reaches teh end of screen, bomb is deleted
        {
            list_bomb.remove(bom);
            delete bom;
        }
    }
}

void MadAnimals::createObject()
{
    AnimalFactory obj;   // to create animal objecys
    Animals.push_back(obj.getObject());
}

//this function is called when player presses space bar key or up arrow key to fire at the animals
void MadAnimals::fire()
{
    cout<<"Shot"<<endl;
    Bullet * bul=new Bullet(sh->get_x(),sh->get_y());
    list_bullets.push_back(bul);
}

int MadAnimals::get_score()
{
    return score;
}


//this function is responsible for bomb implementation
void MadAnimals::bomb_drop(int x, int y){
    cout<<"Shot"<<endl;
    Bomb * bom=new Bomb(x , y);
    list_bomb.push_back(bom);
}


//this function is called to delete all objects and clear the vectors
void MadAnimals::deleteObject()
{
    for(Animal* u: Animals){
        delete u;
        Animals.remove(u);
    }
    Animals.clear(); 

    for(Bullet*& b: list_bullets)
    {
        delete b;
		list_bullets.remove(b);	    
    }
    list_bullets.clear();

    for(Bomb*& b: list_bomb)
    {
        delete b;
		list_bomb.remove(b);
	    
    }
    list_bomb.clear();

}
//this function determines if the game has to end or not
bool MadAnimals :: game_end()
{
    if (flag==true)
    {
        return true;
    }
    return false;
}

//score is a 3 Score objects based implementation and is drawn on the screen using the following function
void MadAnimals:: drawScore()
{    
    int store_var=0;
    int digit_1=score/ 100; //obtain the first digit
    store_var=score % 100;
    int digit_2=store_var/10; //obtain the second digit
    store_var=store_var%10;
    int digit_3=store_var; //obtain the third digit
   
    s1->draw(digit_1); //all the three digits are drawn in respective Score objects
    s2->draw(digit_2);
    s3->draw(digit_3);
}
//default constructor initializes score, life placement, shooter placement, and score placement
MadAnimals::MadAnimals()
{
    sh = new Shooter (730,650);
    l = new Life(150,50);
    int score=50;
    
    s1=new Score(1200, 50);
    s2=new Score(1250, 50);
    s3=new Score(1300, 50);
    
    
    bool flag=false;  //game has not ended yet
    

}
//this function is used in play again implementation
void MadAnimals:: set_score()
{
    score=50;
}

//this function is used in play again implementation
void MadAnimals:: set_health()
{    
    sh->set_health(5);
}

//for every 50+ socre, one bonus health is given
void MadAnimals::bonus_health(){
    int health=sh->get_health()+1;
    sh->set_health(health);
}

//when player is restarting game, this is called
void MadAnimals:: p_again(){
    flag = false;
    // re initilizing of health, score and shooter moverRect
    sh -> set_health(5);
    sh -> set_cord();
    score = 50;
}










