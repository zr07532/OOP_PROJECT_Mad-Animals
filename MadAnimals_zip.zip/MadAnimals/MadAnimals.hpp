#pragma once
#include<SDL.h>
#include "Spider.hpp"
#include "Bat.hpp"
#include "Ladybug.hpp"
#include<vector>
#include<list>
#include "life.hpp"
#include "Animal.hpp"
#include "shooter.hpp"
#include "bullet.hpp"
#include "score.hpp"
#include <SDL_mixer.h>
#include "Explosion.hpp"
#include "bomb.hpp"

using namespace std;

class MadAnimals{

    SDL_Renderer * gRenderer;
    SDL_Texture * assets;
    Score * s1,  * s2, * s3; //3 score pointers for three digit score implementation
    
    public:

    list<Animal*>Animals; //list of all animals
    void drawObjects();  //draws and create objects and includes functionality for score, health implementation too
    void createObject();
    
    list <Bullet*> list_bullets; //list of all bullets
    Explosion * explosive; 
    //Bomb * bomb_dropping;
    list <Bomb*> list_bomb; //list of all bombs
    Shooter * sh;
    Life * l;
    int score=50; //initially the score is set to 50
    bool flag; //responsible to implement the game end logic

    void explosion();
  
    void fire();
    void bomb_drop(int x, int y);

    void killing();
    
    bool game_end();
    void deleteObject();
    int get_score();
    void drawScore();
    
    bool state=false;
    MadAnimals();
    Mix_Music* music=NULL;
    void set_health();
    void set_score();
    void p_again(); //to implement play again logic
    void bonus_health();
    int bonus = 100; //for every 50 score, a bonus life is given


    
};