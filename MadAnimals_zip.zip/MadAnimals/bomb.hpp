#pragma once
#include "drawing.hpp"
#include<SDL.h>
#include <iostream>

using namespace std;

// Bomb class implementation

class Bomb{
    protected:
    SDL_Rect srcRect, moverRect;


public:
    Bomb(){};  
    // function draws the BOMB
    void draw(); 

    // function return co-ordinates of Bomb
    SDL_Rect* getMover();
   
    int get_y();

    Bomb(int x, int y);
    int get_x();
    bool has_exploded();
    void dropped();

    ~ Bomb()
    {
        cout<<"Bombs deleted"<<endl;
    }
};
