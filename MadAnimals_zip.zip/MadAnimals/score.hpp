#pragma once
#include<SDL.h>
#include "drawing.hpp"

class Score{
    SDL_Rect srcRect, moverRect;
    //int count;
    public:
    // add the fly function here as well.
    void draw(int digit);
    
    // may add other overloaded constructors here... 
    Score(int x, int y);

};