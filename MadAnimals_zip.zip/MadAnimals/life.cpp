#include "life.hpp"
using namespace std;
#include <iostream>

//on the basis of health value, life objects are drawn on the screen
void Life::draw(int value){
    
    for (int i=0;i<value;i++)
    {
        SDL_Rect moverrect =moverRect;
        moverrect.x=moverRect.x+((i*40)+10);
        SDL_RenderCopy(Drawing::gRenderer,Drawing::assets,&srcRect,&moverrect);
    }
    
}


Life::Life()
{
    srcRect = {502,620,152,131};
    moverRect={40,560,40,40};
    
}

Life::Life(int x, int y) 
{
    // src coorinates from assets.png file, they have been found using spritecow.com
    srcRect = {502, 620, 152, 131};

    // it will display pigeon on x, y location, the size of pigeon is 50 width, 50 height
    moverRect = {x, y, 40, 40};
}