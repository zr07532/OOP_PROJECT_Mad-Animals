#include<SDL.h>
#include "drawing.hpp"
#include <iostream>

using namespace std;

class Bullet{
    SDL_Rect srcRect, moverRect;
    
    public:
    SDL_Rect* getMover();
    void explosion();
    bool bullet_exploded();
    void draw();
    void shot();
    void hit(SDL_Renderer*, SDL_Texture* );
    Bullet();
    Bullet(int x, int y);
    int get_x();
    int get_y(); 
    int state=0;
    bool complete=false;
    bool exploding=false;
   
};