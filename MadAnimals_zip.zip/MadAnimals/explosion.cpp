#include "Explosion.hpp"
#include <iostream>

using namespace std;

// Animal class is well implemented, no need to change it

// this function will draw explosion animation
void Explosion::draw(){

    if (exploding==true)
    {

        if (state==0) //with increment in stage, animation changes
        {   
            srcRect={100,123,21,20};
            state+=1;
            
        }
        else if (state==1)
        {
            srcRect={177,21,49,45};
            state+=1;
            
        }
        else if (state==2)
        {
            cout<<"in between states"<<endl;
            srcRect={274,16,89,70};
            state+=1;
            
        }
        else if (state==3)
        {
            srcRect={410,16,60,54};
            state+=1;
            
        }
        else if (state==4)
        {
            srcRect={530,18,54,50};
            state+=1;
            
        }
        else if (state==5)
        {
            srcRect={664,293,28,29};
            state+=1;
            complete=true;
            
        }    
        SDL_RenderCopy(Drawing::gRenderer, Drawing::assets1, &srcRect, &moverRect);
        
    }
}


Explosion::Explosion(int x, int y)
{
    srcRect = {100,123,21,20};
    moverRect = {x, y, 30, 80};
}

void Explosion:: fly()
{
    moverRect.y+=0;
}

//this function checks if explosion is completely animated
bool Explosion::has_exploded()
{
    if (complete==true)
    {   
        //complete=false;
        return true;
    }   
    return false;
}