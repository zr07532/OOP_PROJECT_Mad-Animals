#pragma once
#include "drawing.hpp"
#include<SDL.h>
#include <iostream>

using namespace std;
// Unit class is well implemented, no need to change it

class Animal{
    protected:
    SDL_Rect srcRect, moverRect;

public:
    Animal(){};   
    SDL_Rect* getMover();
    virtual void draw();
    virtual void fly() = 0;
    int get_y();
    int get_x();
    virtual ~Animal()
    {
        cout<<"Animals deleted"<<endl;
    }

};
