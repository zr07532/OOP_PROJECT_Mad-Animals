#include<SDL.h>
#include "drawing.hpp"
#include <iostream>

using namespace std;
// class for shooter implementation
class Shooter{
    
    SDL_Rect srcRect, moverRect;

    // default health of shooter set to 5
    int health = 5;
    public:
    void draw();
    void movement(int move);
    Shooter();
    Shooter(int, int);
    bool destroyed();
    int get_x();
    int get_health();
    int get_y();
    SDL_Rect* get_mover();
    void set_health(int h);
    void set_cord();
    bool operator>(int i);
    bool operator<(int i);
    bool operator==(int i);
    //converts shooter object into integer on the basis of health value
    operator int()
    {
        cout<<"here"<<endl;
        return health;
    }  
   ~Shooter(){}
    
};

