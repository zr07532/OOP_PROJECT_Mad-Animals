#pragma once
#include<SDL.h>
#include "drawing.hpp"
#include "Animal.hpp"
#include <iostream>

using namespace std;

// class for Spider implementation inherited from class Animal

class Ladybug : public Animal
{
    int frame = 0; //checks state of butterfly
    bool flag=true; //checks if butterfly should move down or up
    
    public:

    //These functions have been described in Bat.hpp   
    void fly();
    Ladybug(); 

    Ladybug(int x, int y);
    bool next = true;
    int time=15; //hover time
    ~Ladybug()
    {
        cout<<"Ladybugs deleted"<<endl;
    }
};
