#include "Bat.hpp"
#include <iostream>
#include "drawing.hpp"
using namespace std;

// bat implementation will go here.

void Bat::fly(){
    //these if conditions check the movement of the object to decide which image to show on screen
    cout<<"flown"<<endl;
    if (frame == 0)
    {
        srcRect = {436, 235, 393, 106};// Initial state of object
        frame += 1;
    }
    else if (frame == 1)
    {
        srcRect = {452, 389, 354, 161};//flying state of object
        frame += 1;
    }
    else if(frame == 2)
    {
        srcRect = {448, 35, 358, 155};//flying state of object
        frame -= 2;
    }
    else
    {
        frame = 0;
    }

    moverRect.y+=3; //moves the bee 3 pixels Down
    
  
}
Bat::Bat(){
    // src coorinates from assets.png file, they have been found using spritecow.com
    srcRect = {63, 619, 151, 166};

    // it will display bee on x = 30, y = 40 location, the size of bee is 50 width, 50 height
    moverRect = {30, 40, 50, 50};
}

Bat::Bat(int x, int y){
    // src coorinates from assets.png file, they have been found using spritecow.com
    srcRect = {63, 619, 151, 166};

    // it will display bee on x, y location, the size of bat is 25  width, 25 height
    moverRect = {x, y, 70, 70};
}