#pragma once
#include<SDL.h>
#include "drawing.hpp"
#include "Animal.hpp"
#include <iostream>

using namespace std;

// class for Bat implementation inherited from class Animal
class Bat : public Animal
{
    int frame = 0;//checks state of bee

public:
    
    void fly();// function to fly bat
    Bat(); 
    
    // you may add other overloaded constructors here... 
    Bat(int x, int y);// Constructor that takes x & y coordinates as parameters to draw object on screen
    ~Bat()
    {
        cout<<"Bats deleted"<<endl;
    }
};
