#include "Ladybug.hpp"
#include "drawing.hpp"
#include <iostream>
using namespace std;

// ladybug implementation

void Ladybug::fly(){
    //these if conditions check the movement of the object to decide which image to show on screen
    if (frame == 0)
    {
        srcRect = {1081, 133, 167, 154};
        frame += 1;
    }
    else if (frame == 1)
    {
        srcRect = {1280, 121, 163, 174};
        frame += 1;
    }
    else if(frame == 2)
    {
        srcRect = {882, 130, 167, 156};
        frame -= 2;
    }
    else
    {
        frame = 0;
    }

    int a;
    if (flag==true)
    {
        a =rand()%100; //random number generated for probability calculation
    }
    // if probability meets if conditon, the ladybug moves to the right
    if (a<=10 && time>0)
    {
        flag=false; 
        moverRect.y+=0; //no movement to create hover effect
        moverRect.x+=10;  //moves the bee 10 pixels to the right
        if (moverRect.x > 1470 ){
            moverRect.x = 15; // if ladybug crosses the screen, it comes out from the other side
        }
        time--;
        if (time==0)
        {
            flag=true;
        }   
    }
    else 
    {
        moverRect.y+=10; //moves the bee 10 pixels down
    }

}

Ladybug::Ladybug(){
    // src coorinates from assets.png file, they have been found using spritecow.com
    srcRect = {256,24,174,134};

    // it will display butterfly on x = 30, y = 40 location, the size of pigeon is 50 width, 50 height
    moverRect = {30, 40, 50, 50};
}

Ladybug::Ladybug(int x, int y){
    // src coorinates from assets.png file, they have been found using spritecow.com
    srcRect = {256,24,174,134};

    // it will display butterfly on x, y location, the size of butterfly is 50 width, 60 height
    moverRect = {x, y, 50, 60};
}